void playMidi(int melody_num) {
	#include "pitches.h"
	int buzzer = A5;
	int divider = 0, noteDuration = 0, wholenote=0,notes=0,tempo=70;
	int melody0[] = {
	  // Game of Thrones
	  // Score available at https://musescore.com/user/8407786/scores/2156716

	  NOTE_G4,8, NOTE_C4,8, NOTE_DS4,16, NOTE_F4,16, NOTE_G4,8, NOTE_C4,8, NOTE_DS4,16, NOTE_F4,16, //1
	  NOTE_G4,8, NOTE_C4,8, NOTE_DS4,16, NOTE_F4,16, NOTE_G4,8, NOTE_C4,8, NOTE_DS4,16, NOTE_F4,16,
	  NOTE_G4,8, NOTE_C4,8, NOTE_E4,16, NOTE_F4,16, NOTE_G4,8, NOTE_C4,8, NOTE_E4,16, NOTE_F4,16,
	  NOTE_G4,8, NOTE_C4,8, NOTE_E4,16, NOTE_F4,16, NOTE_G4,8, NOTE_C4,8, NOTE_E4,16, NOTE_F4,16,
	  NOTE_G4,-4, NOTE_C4,-4,//5

	  NOTE_DS4,16, NOTE_F4,16, NOTE_G4,4, NOTE_C4,4, NOTE_DS4,16, NOTE_F4,16, //6
	  NOTE_D4,-1, //7 and 8
	  NOTE_F4,-4, NOTE_AS3,-4,
	  NOTE_DS4,16, NOTE_D4,16, NOTE_F4,4, NOTE_AS3,-4,
	  NOTE_DS4,16, NOTE_D4,16, NOTE_C4,-1
	};
	int melody1[] = {
	  // Dart Vader theme (Imperial March) - Star wars 
	  // Score available at https://musescore.com/user/202909/scores/1141521
	  // The tenor saxophone part was used
	  
	  NOTE_A4,-4, NOTE_A4,-4, NOTE_A4,16, NOTE_A4,16, NOTE_A4,16, NOTE_A4,16, NOTE_F4,8, REST,8,
	  NOTE_A4,-4, NOTE_A4,-4, NOTE_A4,16, NOTE_A4,16, NOTE_A4,16, NOTE_A4,16, NOTE_F4,8, REST,8,
	  NOTE_A4,4, NOTE_A4,4, NOTE_A4,4, NOTE_F4,-8, NOTE_C5,16,

	  NOTE_A4,4, NOTE_F4,-8, NOTE_C5,16, NOTE_A4,2,//4
	  NOTE_E5,4, NOTE_E5,4, NOTE_E5,4, NOTE_F5,-8, NOTE_C5,16,
	  NOTE_A4,4, NOTE_F4,-8, NOTE_C5,16, NOTE_A4,2,
	  
	  NOTE_A5,4, NOTE_A4,-8, NOTE_A4,16, NOTE_A5,4, NOTE_GS5,-8, NOTE_G5,16, //7 
	  NOTE_DS5,16, NOTE_D5,16, NOTE_DS5,8, REST,8, NOTE_A4,8, NOTE_DS5,4, NOTE_D5,-8, NOTE_CS5,16,

	  NOTE_C5,16, NOTE_B4,16, NOTE_C5,16, REST,8, NOTE_F4,8, NOTE_GS4,4, NOTE_F4,-8, NOTE_A4,-16,//9
	  NOTE_C5,4, NOTE_A4,-8, NOTE_C5,16, NOTE_E5,2,

	  NOTE_A5,4, NOTE_A4,-8, NOTE_A4,16, NOTE_A5,4, NOTE_GS5,-8, NOTE_G5,16, //7 
	  NOTE_DS5,16, NOTE_D5,16, NOTE_DS5,8, REST,8, NOTE_A4,8, NOTE_DS5,4, NOTE_D5,-8, NOTE_CS5,16,

	  NOTE_C5,16, NOTE_B4,16, NOTE_C5,16, REST,8, NOTE_F4,8, NOTE_GS4,4, NOTE_F4,-8, NOTE_A4,-16,//9
	  NOTE_A4,4, NOTE_F4,-8, NOTE_C5,16, NOTE_A4,2
	};
	int melody2[] = {
		NOTE_G4,8,//1
		NOTE_AS4,4, NOTE_C5,8, NOTE_D5,-8, NOTE_DS5,16, NOTE_D5,8,
		NOTE_C5,4, NOTE_A4,8, NOTE_F4,-8, NOTE_G4,16, NOTE_A4,8,
		NOTE_AS4,4, NOTE_G4,8, NOTE_G4,-8, NOTE_FS4,16, NOTE_G4,8,
		NOTE_A4,4, NOTE_FS4,8, NOTE_D4,4, NOTE_G4,8,

		NOTE_AS4,4, NOTE_C5,8, NOTE_D5,-8, NOTE_DS5,16, NOTE_D5,8,//6
		NOTE_C5,4, NOTE_A4,8, NOTE_F4,-8, NOTE_G4,16, NOTE_A4,8,
		NOTE_AS4,-8, NOTE_A4,16, NOTE_G4,8, NOTE_FS4,-8, NOTE_E4,16, NOTE_FS4,8, 
		NOTE_G4,-2
	};
	int melody3[] = {
		NOTE_E4,4,  NOTE_E4,4,  NOTE_F4,4,  NOTE_G4,4,//1
		NOTE_G4,4,  NOTE_F4,4,  NOTE_E4,4,  NOTE_D4,4,
		NOTE_C4,4,  NOTE_C4,4,  NOTE_D4,4,  NOTE_E4,4,
		NOTE_E4,-4, NOTE_D4,8,  NOTE_D4,2};
	switch (melody_num) {
	  case 0:
		tempo= 85;
		wholenote = (60000 * 4) / tempo;
		notes = sizeof(melody0) / sizeof(melody0[0]) / 2;
		// Remember, the array is twice the number of notes (notes + durations)
		for (int thisNote = 0; thisNote < notes * 2; thisNote = thisNote + 2) {
			// calculates the duration of each note
			divider = melody0[thisNote + 1];
			if (divider > 0) {
			  // regular note, just proceed
			  noteDuration = (wholenote) / divider;
			} else if (divider < 0) {
			  // dotted notes are represented with negative durations!!
			  noteDuration = (wholenote) / abs(divider);
			  noteDuration *= 1.5; // increases the duration in half for dotted notes
			}
			// we only play the note for 90% of the duration, leaving 10% as a pause
			tone(buzzer, melody0[thisNote], noteDuration * 0.9);
			delay(noteDuration);
			noTone(buzzer);
		}
		break;
	  case 1:
		tempo = 120;
		wholenote = (60000 * 4) / tempo;
		notes = sizeof(melody1) / sizeof(melody1[0]) / 2;
		// Remember, the array is twice the number of notes (notes + durations)
		for (int thisNote = 0; thisNote < notes * 2; thisNote = thisNote + 2) {
			// calculates the duration of each note
			divider = melody1[thisNote + 1];
			if (divider > 0) {
			  // regular note, just proceed
			  noteDuration = (wholenote) / divider;
			} else if (divider < 0) {
			  // dotted notes are represented with negative durations!!
			  noteDuration = (wholenote) / abs(divider);
			  noteDuration *= 1.5; // increases the duration in half for dotted notes
			}
			// we only play the note for 90% of the duration, leaving 10% as a pause
			tone(buzzer, melody1[thisNote], noteDuration * 0.9);
			delay(noteDuration);
			noTone(buzzer);
		}
		break;
	  case 2:
		tempo = 70;
		wholenote = (60000 * 4) / tempo;
		notes = sizeof(melody2) / sizeof(melody2[0]) / 2;
		// Remember, the array is twice the number of notes (notes + durations)
		for (int thisNote = 0; thisNote < notes * 2; thisNote = thisNote + 2) {
			// calculates the duration of each note
			divider = melody2[thisNote + 1];
			if (divider > 0) {
			  // regular note, just proceed
			  noteDuration = (wholenote) / divider;
			} else if (divider < 0) {
			  // dotted notes are represented with negative durations!!
			  noteDuration = (wholenote) / abs(divider);
			  noteDuration *= 1.5; // increases the duration in half for dotted notes
			}
			// we only play the note for 90% of the duration, leaving 10% as a pause
			tone(buzzer, melody2[thisNote], noteDuration * 0.9);
			delay(noteDuration);
			noTone(buzzer);
		}
		break;
	  case 3:
		tempo = 114;
		wholenote = (60000 * 4) / tempo;
		notes = sizeof(melody3) / sizeof(melody3[0]) / 2;
		// Remember, the array is twice the number of notes (notes + durations)
		for (int thisNote = 0; thisNote < notes * 2; thisNote = thisNote + 2) {
			// calculates the duration of each note
			divider = melody3[thisNote + 1];
			if (divider > 0) {
			  // regular note, just proceed
			  noteDuration = (wholenote) / divider;
			} else if (divider < 0) {
			  // dotted notes are represented with negative durations!!
			  noteDuration = (wholenote) / abs(divider);
			  noteDuration *= 1.5; // increases the duration in half for dotted notes
			}
			// we only play the note for 90% of the duration, leaving 10% as a pause
			tone(buzzer, melody3[thisNote], noteDuration * 0.9);
			delay(noteDuration);
			noTone(buzzer);
		}
		break;
	}
	
}
